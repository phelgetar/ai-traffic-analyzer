import { Incident } from '../types';

// API Keys and Endpoints from user
const OHGO_API_KEY = '974bd202-b765-4a25-8ee2-a4d858d87bff';
const DRIVETEXAS_API_KEY = '282b3686-c1a2-4f20-9a53-53027e71c1c3';

const OHGO_API_URL_INCIDENTS = 'https://publicapi.ohgo.com/api/v1/incidents';
const OHGO_API_URL_CONSTRUCTION = 'https://publicapi.ohgo.com/api/v1/construction';
const OHGO_API_URL_SLOWDOWNS = 'https://publicapi.ohgo.com/api/v1/dangerous-slowdowns';
const OHGO_API_URL_DELAYS = 'https://publicapi.ohgo.com/api/v1/travel-delays';


// Updated to use the correct GeoJSON endpoint provided in the API documentation.
const DRIVETEXAS_API_URL = `https://api.drivetexas.org/api/conditions.geojson?key=${DRIVETEXAS_API_KEY}`;
// New endpoint for detailed work zone / construction data
const DRIVETEXAS_WZDX_API_URL = `https://api.drivetexas.org/api/conditions.wzdx.geojson?key=${DRIVETEXAS_API_KEY}`;

// By requesting data for all districts, we ensure a comprehensive statewide feed.
const ALL_OHIO_DISTRICTS = '1,2,3,4,5,6,7,8,9,10,11,12';

// --- START: Added for Debug Pane ---
// A temporary, module-level variable to store raw responses for debugging purposes.
let rawOhgoDebugData: Record<string, any> = {};

export interface FetchResult {
    incidents: Incident[];
    debugData: Record<string, any>;
}
// --- END: Added for Debug Pane ---

/**
 * Validates latitude and longitude values to ensure they are within valid geographical ranges.
 * @param lat The latitude to validate.
 * @param lon The longitude to validate.
 * @returns An object with validated latitude and longitude, or null if invalid.
 */
const validateCoordinates = (lat: any, lon: any): { latitude: number | null; longitude: number | null } => {
    const parsedLat = lat !== null && lat !== undefined ? parseFloat(lat) : NaN;
    const parsedLon = lon !== null && lon !== undefined ? parseFloat(lon) : NaN;

    const isLatValid = !isNaN(parsedLat) && parsedLat >= -90 && parsedLat <= 90;
    const isLonValid = !isNaN(parsedLon) && parsedLon >= -180 && parsedLon <= 180;

    return {
        latitude: isLatValid ? parsedLat : null,
        longitude: isLonValid ? parsedLon : null,
    };
};


/**
 * Transforms a raw event object from the OHGO API into the application's Incident type.
 * This function has been enhanced to be more resilient to variations in the API data,
 * ensuring that key details like location and county are reliably extracted.
 */
const transformOhgoEvent = (ohgoEvent: any, category: 'INCIDENT' | 'ROADWORK'): Incident => {
  // FIX: Use 'id' instead of 'eventId' to match the provided API documentation.
  const numericId = ohgoEvent.id ?
      Array.from(String(ohgoEvent.id)).reduce((s, c) => Math.imul(31, s) + c.charCodeAt(0) | 0, 0)
      : Math.floor(Math.random() * 1e9);

  // --- Robust Coordinate Extraction ---
  let lat: any = null;
  let lon: any = null;

  if (ohgoEvent.latitude !== undefined && ohgoEvent.longitude !== undefined) {
      lat = ohgoEvent.latitude;
      lon = ohgoEvent.longitude;
  } else if (ohgoEvent.geometry?.coordinates && Array.isArray(ohgoEvent.geometry.coordinates) && ohgoEvent.geometry.coordinates.length >= 2) {
      // GeoJSON format: [longitude, latitude]
      lon = ohgoEvent.geometry.coordinates[0];
      lat = ohgoEvent.geometry.coordinates[1];
  }
  const { latitude, longitude } = validateCoordinates(lat, lon);
  // --- End Coordinate Extraction ---

  const description = (ohgoEvent.description || 'No description available.').trim();
  const locationString = (ohgoEvent.location || '').trim();
  const routeName = (ohgoEvent.routeName || '').trim();
  const direction = (ohgoEvent.directionOfTravel || '').replace('bound', '').trim();
  
  // --- Refined Event Type, Severity, and Closure Logic (as per user request) ---

  // 1. Determine the event type, using the more specific eventCode as a fallback if eventType is generic.
  let eventType = ohgoEvent.eventType;
  if ((!eventType || ['incident', 'roadwork'].includes(String(eventType).toLowerCase())) && ohgoEvent.eventCode) {
    eventType = ohgoEvent.eventCode;
  }
  // Ensure a final eventType is set based on the category if it's still missing.
  eventType = eventType || (category === 'ROADWORK' ? 'Roadwork' : 'Incident');

  // 2. Process severity, prioritizing severityFlag and ensuring a valid default.
  const rawSeverity = ohgoEvent.severityFlag || ohgoEvent.severity;
  const severity_flag = (String(rawSeverity || 'LOW').toUpperCase()) as Incident['severity_flag'];

  // 3. Process closure status, prioritizing closureStatus and ensuring a valid default.
  // FIX: Added 'roadStatus' as a primary source for closure info, per API documentation.
  const rawClosure = ohgoEvent.roadStatus || ohgoEvent.closureStatus || ohgoEvent.closureType;
  const closure_status = (String(rawClosure || 'UNKNOWN').toUpperCase()) as Incident['closure_status'];
  
  // --- End Refined Logic ---

  let county = null;
  if (ohgoEvent.county) {
      county = String(ohgoEvent.county).replace(/ County/i, '').trim();
  } else {
      const combinedTextForCounty = `${description} ${locationString}`;
      const countyMatch = combinedTextForCounty.match(/\b([\w\s'-]+)\s+County\b/i);
      if (countyMatch && countyMatch[1]) {
          county = countyMatch[1].trim();
      }
  }

  let displayTitle = '';
  if (routeName) {
      displayTitle = [routeName, direction].filter(Boolean).join(' ');
  } else if (locationString) {
      displayTitle = locationString;
  } else if (eventType && county) {
      displayTitle = `${eventType} in ${county} County`;
  } else if (description !== 'No description available.') {
      displayTitle = description.split('.')[0];
      if (displayTitle.length > 80) {
          displayTitle = displayTitle.substring(0, 80) + '...';
      }
  } else {
      displayTitle = `${eventType} Report`;
  }
  
  const isActive = ohgoEvent.isActive !== undefined
    ? (String(ohgoEvent.isActive) === '1' || String(ohgoEvent.isActive).toLowerCase() === 'true')
    : true;


  return {
    id: numericId,
    // FIX: Use 'id' instead of 'eventId'
    uuid: ohgoEvent.uuid || ohgoEvent.id || `ohgo-${numericId}`,
    source_system: 'OHGO',
    // FIX: Use 'id' instead of 'eventId'
    source_event_id: ohgoEvent.id || null,
    state: 'OH',
    county: county,
    route: displayTitle,
    routeName: routeName || null,
    direction: direction,
    milepost: ohgoEvent.mileMarker || null,
    latitude: latitude,
    longitude: longitude,
    reported_time: ohgoEvent.startTime || new Date().toISOString(),
    updated_time: ohgoEvent.lastUpdated || new Date().toISOString(),
    end_time: null,
    is_active: isActive,
    category: category,
    event_type: eventType,
    lanes_affected: ohgoEvent.lanesAffected || 'Not specified',
    closure_status: closure_status,
    severity_flag: severity_flag,
    severity_score: null,
    units_involved: null,
    description: description,
  };
};

/**
 * Transforms a raw GeoJSON feature from the DriveTexas API into the application's Incident type.
 * This function is now more robust, checking for both PascalCase and snake_case property names
 * for all relevant fields to handle API inconsistencies gracefully.
 */
const transformDriveTexasEvent = (feature: any): Incident => {
    const props = feature.properties || {};
    const geometry = feature.geometry || {};
    
    // Check both casings for the unique identifier.
    const eventId = props.ConditionID || props.condition_id || JSON.stringify(props);
    const numericId = Array.from(String(eventId)).reduce((s, c) => Math.imul(31, s) + c.charCodeAt(0) | 0, 0);

    const description = props.Description || props.description || '';
    const descriptionLower = description.toLowerCase();
    
    let closure: Incident['closure_status'] = 'UNKNOWN';
    if (descriptionLower.includes('all lanes blocked') || descriptionLower.includes('road closed')) {
        closure = 'CLOSED';
    } else if (descriptionLower.includes('lane closed') || descriptionLower.includes('lane blocked')) {
        closure = 'PARTIAL';
    }

    // Check both casings for event type.
    let eventType = props.ConditionType || props.condition_type || 'Incident';
    if (descriptionLower.includes('accident') || descriptionLower.includes('crash')) {
        eventType = 'Crash';
        if (descriptionLower.includes('injury')) eventType = 'Crash with Injury';
        if (descriptionLower.includes('major')) eventType = 'Major Crash';
    } else if (descriptionLower.includes('stalled vehicle')) {
        eventType = 'Stalled Vehicle';
    }
    
    // Per requirements, check for both 'CountyName' and 'county_name'. If absent, use regex on description.
    let county = props.CountyName || props.county_name || null;
    if (!county && description) {
        const countyMatch = description.match(/\b([\w\s'-]+)\s+County\b/i);
        if (countyMatch && countyMatch[1]) {
            county = countyMatch[1].trim();
        }
    }
    
    // More robust route name extraction for filtering and display.
    // Prioritize the specific roadway name field.
    let routeName = props.RoadwayName || props.roadway_name || null;
    let route = routeName;

    // If no specific name, check the location description. This might contain names like 'FM-1774'.
    // If we find something here, we'll use it for both display and filtering.
    const locationDesc = props.LocationDescription || props.location_description;
    if (!routeName && locationDesc) {
        // Use the first part of the location description as the canonical name for filtering
        routeName = locationDesc.split(',')[0].trim();
        route = locationDesc; // Use the full description for display
    }

    // Fallback logic for the display route if we still have nothing.
    if (!route || route.trim() === '') {
        if (eventType && county) {
            route = `${eventType} in ${county} County`;
        } else if (description) {
            route = description.split('.')[0];
        } else {
            route = 'Unspecified Incident';
        }
    }

    let severity: Incident['severity_flag'] = 'LOW';
    if (descriptionLower?.includes('major') || eventType.toLowerCase().includes('crash')) {
        severity = 'MEDIUM';
    }
    if (descriptionLower?.includes('critical') || closure === 'CLOSED') {
        severity = 'HIGH';
    }

    // --- Robust Coordinate Extraction ---
    let lat: any = null;
    let lon: any = null;
    const coords = geometry.coordinates;
    if (coords && Array.isArray(coords) && coords.length >= 2) {
        // Standard GeoJSON [longitude, latitude]
        lon = coords[0];
        lat = coords[1];
    } else {
        // Fallback to properties, checking multiple casings
        lat = props.Latitude || props.latitude;
        lon = props.Longitude || props.longitude;
    }
    const { latitude, longitude } = validateCoordinates(lat, lon);
    
    // Check both casings for all remaining fields.
    const sourceEventId = props.ConditionID || props.condition_id || null;
    const direction = (props.DirectionOfTravel || props.direction_of_travel || '').replace('bound', '');
    const reportedTime = props.StartDate || props.start_date || new Date().toISOString();
    const updatedTime = props.LastUpdated || props.last_updated || new Date().toISOString();
    const isActive = (props.ConditionStatus || props.condition_status) !== 'Expired';
    const lanesAffected = props.LanesAffected || props.lanes_affected || 'Not specified';

    return {
        id: numericId,
        uuid: sourceEventId || `tx-${numericId}`,
        source_system: 'DriveTexas',
        source_event_id: sourceEventId,
        state: 'TX',
        county: county,
        route: route,
        routeName: routeName,
        direction: direction,
        milepost: null,
        latitude: latitude,
        longitude: longitude,
        reported_time: reportedTime,
        updated_time: updatedTime,
        end_time: null,
        is_active: isActive,
        category: 'INCIDENT',
        event_type: eventType,
        lanes_affected: lanesAffected,
        closure_status: closure,
        severity_flag: severity,
        severity_score: null,
        units_involved: null,
        description: description,
    };
};


/**
 * Transforms a raw WZDx GeoJSON feature from the DriveTexas API into our Incident type.
 */
const transformDriveTexasWzdxEvent = (feature: any): Incident => {
    const props = feature.properties || {};
    const core = props.core_details || {};
    
    const eventId = props.road_event_id || JSON.stringify(props);
    const numericId = Array.from(String(eventId)).reduce((s, c) => Math.imul(31, s) + c.charCodeAt(0) | 0, 0);

    const status = (props.event_status || 'active').toLowerCase();
    const isInactive = status === 'completed' || status === 'cancelled';
    
    let closure: Incident['closure_status'] = 'PARTIAL';
    if (props.lanes?.every((l: any) => l.status === 'closed')) closure = 'CLOSED';
    if (isInactive) closure = 'OPEN';
    
    const description = props.description || '';
    
    let county = null;
    const countyMatch = description.match(/\b(\w+)\s+County\b/i);
    if (countyMatch && countyMatch[1]) county = countyMatch[1];
    
    let route = core.road_names?.[0];
    if (!route) {
        if (county) {
            route = `Roadwork in ${county} County`;
        } else if (description) {
            route = description.split('.')[0];
        } else {
            route = 'Unspecified Roadwork';
        }
    }
    
    // --- Robust Coordinate Extraction ---
    const lat = core.latitude || core.Latitude;
    const lon = core.longitude || core.Longitude;
    const { latitude, longitude } = validateCoordinates(lat, lon);

    return {
        id: numericId,
        uuid: props.road_event_id || `tx-wzdx-${numericId}`,
        source_system: 'DriveTexas WZDx',
        source_event_id: props.road_event_id || null,
        state: 'TX',
        county: county,
        route: route,
        routeName: core.road_names?.[0] || null,
        direction: core.direction || '',
        milepost: null,
        latitude: latitude,
        longitude: longitude,
        reported_time: props.start_date || new Date().toISOString(),
        updated_time: props.update_date || new Date().toISOString(),
        end_time: props.end_date || null,
        is_active: !isInactive,
        category: 'ROADWORK',
        event_type: props.types_of_work?.[0]?.type_name || 'Roadwork',
        lanes_affected: `${props.lanes?.length || 0} lane(s) affected`,
        closure_status: closure,
        severity_flag: 'MEDIUM',
        severity_score: null,
        units_involved: null,
        description: description,
    };
};

const fetchOhgoData = async (url: string, propertyName: string, category: 'INCIDENT' | 'ROADWORK'): Promise<Incident[]> => {
    const fullUrl = `${url}?api-key=${OHGO_API_KEY}&districts=${ALL_OHIO_DISTRICTS}&pageSize=500`;
    
    try {
        const response = await fetch(fullUrl);

        if (!response.ok) {
            throw new Error(`OHGO API request failed for ${fullUrl} with status ${response.status}`);
        }
        
        const data = await response.json();
        
        // FIX: Per API documentation, the incident list is always in a 'results' property.
        // This replaces the previous, fragile logic that incorrectly guessed the property name.
        const eventsArray = data?.results;

        // Store the raw, complete response object for better debugging.
        rawOhgoDebugData[propertyName] = data;

        if (!Array.isArray(eventsArray)) {
            console.error(`OHGO response from ${url} did not contain the expected 'results' array. Response data:`, data);
            return []; // Return empty array on parsing failure for resilience
        }
        
        const transformedIncidents = eventsArray
            .map(event => {
                try {
                    if (typeof event !== 'object' || event === null) return null;
                    return transformOhgoEvent(event, category);
                } catch (e) {
                    console.error("Failed to transform a single OHGO event, skipping:", event, e);
                    return null;
                }
            })
            .filter((incident): incident is Incident => incident !== null);
        
        return transformedIncidents;

    } catch (error) {
        console.error(`A critical error occurred while fetching or parsing OHGO data from ${fullUrl}:`, error);
        // Make app resilient to a single API failure by returning an empty array.
        return [];
    }
};

const fetchDriveTexasIncidents = async (): Promise<Incident[]> => {
    const response = await fetch(DRIVETEXAS_API_URL);
    if (!response.ok) {
        throw new Error(`DriveTexas API request failed with status ${response.status}`);
    }
    const data = await response.json();
    const features = data.features;
    if (!Array.isArray(features)) {
      console.error("DriveTexas response does not contain a features array:", data);
      return [];
    }
    return features.map(transformDriveTexasEvent);
};

const fetchDriveTexasWzdxIncidents = async (): Promise<Incident[]> => {
    const response = await fetch(DRIVETEXAS_WZDX_API_URL);
    if (!response.ok) {
        throw new Error(`DriveTexas WZDx API request failed with status ${response.status}`);
    }
    const data = await response.json();
    const features = data.features;
    if (!Array.isArray(features)) {
      console.error("DriveTexas WZDx response does not contain a features array:", data);
      return [];
    }
    return features.map(transformDriveTexasWzdxEvent);
};


export const fetchLatestIncidents = async (): Promise<FetchResult> => {
    // Reset debug data at the start of each fetch cycle.
    rawOhgoDebugData = {};
    
    const results = await Promise.allSettled([
        fetchOhgoData(OHGO_API_URL_INCIDENTS, 'incidents', 'INCIDENT'),
        fetchOhgoData(OHGO_API_URL_CONSTRUCTION, 'construction', 'ROADWORK'),
        fetchOhgoData(OHGO_API_URL_SLOWDOWNS, 'dangerousSlowdowns', 'INCIDENT'),
        fetchOhgoData(OHGO_API_URL_DELAYS, 'travelDelays', 'INCIDENT'),
        fetchDriveTexasIncidents(),
        fetchDriveTexasWzdxIncidents(),
    ]);

    const allIncidents: Incident[] = results.flatMap(result => {
        if (result.status === 'fulfilled') {
            return result.value;
        } else {
            console.error('An API call failed:', result.reason);
            return [];
        }
    });

    const sortedIncidents = allIncidents.sort(
        (a, b) => new Date(b.reported_time).getTime() - new Date(a.reported_time).getTime()
    );

    return { incidents: sortedIncidents, debugData: rawOhgoDebugData };
};