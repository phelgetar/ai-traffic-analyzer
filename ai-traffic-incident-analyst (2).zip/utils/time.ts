export const getTimeAgo = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (seconds < 5) {
    return "just now";
  }

  let interval = seconds / 31536000;
  if (interval > 1) {
    const years = Math.floor(interval);
    return `${years} year${years > 1 ? 's' : ''} ago`;
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    const months = Math.floor(interval);
    return `${months} month${months > 1 ? 's' : ''} ago`;
  }
  interval = seconds / 86400;
  if (interval > 1) {
    const days = Math.floor(interval);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }
  interval = seconds / 3600;
  if (interval > 1) {
    const hours = Math.floor(interval);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  }
  interval = seconds / 60;
  if (interval > 1) {
    const minutes = Math.floor(interval);
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  }
  return Math.floor(seconds) + " seconds ago";
};

/**
 * Formats a date string into a more readable format, including both the absolute date/time
 * and a relative "time ago" string.
 * Example: "Jul 29, 2024, 5:45 PM (2 hours ago)"
 */
export const formatDateTime = (dateString: string): string => {
  if (!dateString) return 'N/A';
  try {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    };
    const formattedDate = new Intl.DateTimeFormat('en-US', options).format(date);
    return `${formattedDate} (${getTimeAgo(dateString)})`;
  } catch (e) {
    return dateString; // Fallback to original string if date is invalid
  }
};

/**
 * Calculates the remaining time until a future date and returns a human-readable string.
 * Example: "Clears in 2 hours"
 */
export const formatRemainingTime = (dateString: string): string | null => {
  const endDate = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((endDate.getTime() - now.getTime()) / 1000);

  if (seconds <= 0) {
    return null; // Event has already ended
  }

  const days = Math.floor(seconds / 86400);
  if (days > 1) return `in ${days} days`;
  if (days === 1) return 'in 1 day';

  const hours = Math.floor(seconds / 3600);
   if (hours > 1) return `in ${hours} hours`;
   if (hours === 1) return 'in 1 hour';

  const minutes = Math.floor(seconds / 60);
  if (minutes > 1) return `in ${minutes} mins`;

  return "soon";
};