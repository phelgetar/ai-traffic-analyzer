
export interface Incident {
    id: number;
    uuid: string;
    source_system: string;
    source_event_id: string | null;
    state: string | null;
    county: string | null;
    route: string | null; // This is often used as the main display title
    routeName: string | null; // Specific route name for filtering (e.g., 'I-75')
    direction: string | null;
    milepost: number | null;
    latitude: number | null;
    longitude: number | null;
    reported_time: string; // ISO 8601 string
    updated_time: string; // ISO 8601 string
    end_time: string | null; // ISO 8601 string, for estimated clearance
    is_active: boolean;
    category: 'INCIDENT' | 'ROADWORK';
    event_type: string | null;
    lanes_affected: string | null;
    closure_status: 'OPEN' | 'CLOSED' | 'PARTIAL' | 'UNKNOWN' | null;
    severity_flag: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | null;
    severity_score: number | null;
    units_involved: number | null;
    description: string;
}

export interface WeatherData {
    temperature: string; // e.g., "75°F"
    conditions: string;  // e.g., "Light Rain"
    wind: string;        // e.g., "10 mph SW"
}

export interface AISummary {
    summary: string;
    confidence: 'HIGH' | 'MEDIUM' | 'LOW';
    reasoning: string;
}


// These are based on the schema but not used in the initial UI.
// They are here for future expansion.
export interface PersonNonPii {
    id: number;
    incident_id: number;
    sex: 'MALE' | 'FEMALE' | 'UNKNOWN' | null;
    age_range: string | null;
    occupant_role: string | null;
    injury_severity: string | null;
}

export interface Road {
    id: number;
    source_system: string | null;
    road_id: string | null;
    name: string | null;
    direction: string | null;
}