
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Header from './components/Header';
import IncidentList from './components/IncidentList';
import IncidentDetail from './components/IncidentDetail';
import ErrorMessage from './components/ErrorMessage';
import HistoryList from './components/HistoryList';
import NotificationContainer from './components/NotificationToast';
import FilterControls, { Filters } from './components/FilterControls';
import LocationPermissionBanner from './components/LocationPermissionBanner';
import FeedbackModal from './components/FeedbackModal'; // New import
import DebugPane from './components/DebugPane'; // New import
import { fetchLatestIncidents } from './services/api';
import { summarizeIncident } from './services/geminiService';
import { useLocation } from './hooks/useLocation';
import { usePrevious } from './hooks/usePrevious';
import { Incident, WeatherData, AISummary } from './types';
import { calculateDistance } from './utils/location';

// Exporting Notification type for NotificationToast component
export interface Notification {
  id: number;
  message: string;
  type: Incident['severity_flag'];
}

const App: React.FC = () => {
  const [allIncidents, setAllIncidents] = useState<Incident[]>([]);
  const [filteredIncidents, setFilteredIncidents] = useState<Incident[]>([]);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  
  // Load view history from localStorage on initial render
  const [viewHistory, setViewHistory] = useState<Incident[]>(() => {
    try {
      const savedHistory = localStorage.getItem('incidentViewHistory');
      return savedHistory ? JSON.parse(savedHistory) : [];
    } catch (error) {
      console.error("Failed to load view history from localStorage", error);
      return [];
    }
  });
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [summary, setSummary] = useState<AISummary | null>(null);
  const [isSummaryLoading, setIsSummaryLoading] = useState(false);

  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  const { location: userLocation, permissionStatus, requestLocation, stopTracking, isTracking } = useLocation();

  const [filters, setFilters] = useState<Filters>(() => {
    const defaultFilters: Filters = {
      query: '',
      state: '',
      severity: '',
      route: '',
      category: '',
      status: '',
      startDate: '',
      endDate: '',
    };
    try {
      const savedFilters = localStorage.getItem('trafficIncidentFilters');
      if (savedFilters) {
        const parsedFilters = JSON.parse(savedFilters);
        if (typeof parsedFilters === 'object' && parsedFilters !== null) {
          return {
            query: String(parsedFilters.query || ''),
            state: String(parsedFilters.state || ''),
            severity: String(parsedFilters.severity || ''),
            route: String(parsedFilters.route || ''),
            category: String(parsedFilters.category || ''),
            status: String(parsedFilters.status || ''),
            startDate: String(parsedFilters.startDate || ''),
            endDate: String(parsedFilters.endDate || ''),
          };
        }
      }
    } catch (error) {
      console.error("Failed to load filters from localStorage", error);
    }
    return defaultFilters;
  });

  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  // FIX: Corrected the type for the `debugData` state from `Record<string, any[]>` to `Record<string, any>` to accurately reflect the structure of the API debug data.
  const [debugData, setDebugData] = useState<Record<string, any> | null>(null);

  const prevIncidents = usePrevious(allIncidents);

  useEffect(() => {
    try {
      localStorage.setItem('incidentViewHistory', JSON.stringify(viewHistory));
    } catch (error) {
      console.error("Failed to save view history to localStorage", error);
    }
  }, [viewHistory]);
  
  useEffect(() => {
    try {
      localStorage.setItem('trafficIncidentFilters', JSON.stringify(filters));
    } catch (error) {
      console.error("Failed to save filters to localStorage", error);
    }
  }, [filters]);


  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { incidents, debugData } = await fetchLatestIncidents();
      setAllIncidents(incidents);
      setDebugData(debugData);
      setLastUpdated(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60 * 1000); // Refresh every 60 seconds for a near real-time feel
    return () => clearInterval(interval);
  }, [fetchData]);

  useEffect(() => {
    if (!prevIncidents || prevIncidents.length === 0 || allIncidents.length === 0) {
        return;
    }
    const prevIncidentIds = new Set(prevIncidents.map(i => i.uuid));
    const newIncidents = allIncidents.filter(i => !prevIncidentIds.has(i.uuid));

    const newHighSeverityIncidents = newIncidents.filter(
        i => i.is_active && (i.severity_flag === 'CRITICAL' || i.severity_flag === 'HIGH')
    );
    
    newHighSeverityIncidents.forEach(incident => {
        setNotifications(prev => [
            ...prev,
            {
                id: Date.now() + Math.random(),
                message: `New incident reported on ${incident.route} in ${incident.county} County.`,
                type: incident.severity_flag,
            }
        ]);
    });
  }, [allIncidents, prevIncidents]);


  const handleSelectIncident = useCallback(async (incident: Incident) => {
    setSelectedIncident(incident);
    setSummary(null);
    setIsSummaryLoading(true);

    if (!viewHistory.find(i => i.uuid === incident.uuid)) {
        setViewHistory(prev => [incident, ...prev].slice(0, 5));
    }

    try {
      const weather: WeatherData | null = null;
      
      // --- START: New logic to gather contextual data for AI ---
      const { latitude, longitude, routeName } = incident;
      let nearbyIncidents: Incident[] = [];
      let historicalIncidents: Incident[] = [];

      if (latitude && longitude) {
        // Find nearby ACTIVE incidents within a 5-mile radius
        nearbyIncidents = allIncidents.filter(i => 
          i.uuid !== incident.uuid &&
          i.is_active &&
          i.latitude && i.longitude &&
          calculateDistance(latitude, longitude, i.latitude, i.longitude) <= 5
        ).slice(0, 5); // Limit to 5 to keep prompt concise

        // Find historical (CLEARED) incidents on the same route within a 2-mile radius
        historicalIncidents = allIncidents.filter(i =>
          i.uuid !== incident.uuid &&
          !i.is_active &&
          i.routeName === routeName && // Match the specific route for relevance
          i.latitude && i.longitude &&
          calculateDistance(latitude, longitude, i.latitude, i.longitude) <= 2
        ).slice(0, 5); // Limit to the 5 most recent for brevity
      }
      // --- END: New logic ---

      const incidentSummary = await summarizeIncident(incident, weather, nearbyIncidents, historicalIncidents);
      setSummary(incidentSummary);
    } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
        setSummary({
            summary: `Failed to generate AI summary. Please check the incident details. Error: ${errorMessage}`,
            confidence: 'LOW',
            reasoning: 'A critical error occurred while fetching the summary.'
        });
    } finally {
      setIsSummaryLoading(false);
    }
  }, [viewHistory, allIncidents]);

  const handleFilterChange = (name: keyof Filters, value: string) => {
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleLocationToggle = isTracking ? stopTracking : requestLocation;

  const handleFeedbackSubmit = (feedback: string) => {
    console.log("--- User Feedback Submitted ---", feedback);
    try {
      const storedFeedback = localStorage.getItem('userFeedbackHistory');
      const feedbackHistory = storedFeedback ? JSON.parse(storedFeedback) : [];

      const newFeedbackEntry = {
        id: Date.now(),
        text: feedback,
        timestamp: new Date().toISOString(),
      };

      feedbackHistory.push(newFeedbackEntry);
      localStorage.setItem('userFeedbackHistory', JSON.stringify(feedbackHistory));
      
      alert("Thank you for your feedback! It has been saved locally.");
    } catch (error) {
      console.error("Failed to save feedback to localStorage:", error);
      alert("There was an error saving your feedback.");
    }
    
    setIsFeedbackModalOpen(false);
  };

  useEffect(() => {
    let incidents = allIncidents;

    if (filters.query) {
      const queryLower = filters.query.toLowerCase();
      incidents = incidents.filter(i => 
        i.route?.toLowerCase().includes(queryLower) ||
        i.routeName?.toLowerCase().includes(queryLower) ||
        i.county?.toLowerCase().includes(queryLower) ||
        i.description.toLowerCase().includes(queryLower) ||
        i.event_type?.toLowerCase().includes(queryLower)
      );
    }
    if (filters.state) {
      incidents = incidents.filter(i => i.state === filters.state);
    }
    if (filters.severity) {
      incidents = incidents.filter(i => i.severity_flag === filters.severity);
    }
    if (filters.route) {
        incidents = incidents.filter(i => i.routeName === filters.route);
    }
    if (filters.category) {
        incidents = incidents.filter(i => i.category === filters.category);
    }
    if (filters.status) {
        if (filters.status === 'ACTIVE') {
            incidents = incidents.filter(i => i.is_active);
        } else if (filters.status === 'CLEARED') {
            incidents = incidents.filter(i => !i.is_active);
        }
    }
    if (filters.startDate) {
        const start = new Date(filters.startDate).setHours(0, 0, 0, 0);
        incidents = incidents.filter(i => new Date(i.reported_time).getTime() >= start);
    }
    if (filters.endDate) {
        const end = new Date(filters.endDate).setHours(23, 59, 59, 999);
        incidents = incidents.filter(i => new Date(i.reported_time).getTime() <= end);
    }


    setFilteredIncidents(incidents);
  }, [allIncidents, filters]);
  
  const incidentStats = useMemo(() => {
    const states = [...new Set(allIncidents.map(i => i.state).filter(Boolean) as string[])].sort();
    const severities = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
    const routes = [...new Set(allIncidents.map(i => i.routeName).filter((r): r is string => !!r))].sort();

    const counts = {
        states: {} as { [key: string]: number },
        severities: {} as { [key: string]: number },
        categories: {} as { [key: string]: number },
        status: {} as { [key:string]: number },
    };

    for (const incident of allIncidents) {
        if (incident.state) {
            counts.states[incident.state] = (counts.states[incident.state] || 0) + 1;
        }
        if (incident.severity_flag) {
            counts.severities[incident.severity_flag] = (counts.severities[incident.severity_flag] || 0) + 1;
        }
        if (incident.category) {
            counts.categories[incident.category] = (counts.categories[incident.category] || 0) + 1;
        }
        const statusKey = incident.is_active ? 'ACTIVE' : 'CLEARED';
        counts.status[statusKey] = (counts.status[statusKey] || 0) + 1;
    }

    return { total: allIncidents.length, states, severities, routes, counts };
  }, [allIncidents]);

  const dismissNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleDownloadData = useCallback(() => {
    if (filteredIncidents.length === 0) {
      alert("No incidents to download for the current filter.");
      return;
    }

    const dataStr = JSON.stringify(filteredIncidents, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    const timestamp = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
    link.download = `traffic_incidents_${timestamp}.json`;
    link.href = url;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [filteredIncidents]);


  return (
    <div className="h-screen w-screen bg-slate-100 flex flex-col font-sans">
      <Header 
        onRefresh={fetchData} 
        isLoading={isLoading} 
        onToggleLocation={handleLocationToggle} 
        isTracking={isTracking}
        onFeedbackClick={() => setIsFeedbackModalOpen(true)}
      />
      <NotificationContainer notifications={notifications} onDismiss={dismissNotification} />
      <FeedbackModal 
        isOpen={isFeedbackModalOpen}
        onClose={() => setIsFeedbackModalOpen(false)}
        onSubmit={handleFeedbackSubmit}
      />

      <main className="flex-grow grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 overflow-hidden">
        
        <div className="lg:col-span-1 xl:col-span-1 bg-white flex flex-col shadow-lg z-10 min-h-0">
            <FilterControls filters={filters} onFilterChange={handleFilterChange} incidentStats={incidentStats} onDownloadData={handleDownloadData} />
            {permissionStatus === 'prompt' && <LocationPermissionBanner onRequest={requestLocation} />}
            {error && <div className="p-4"><ErrorMessage message={error} /></div>}
            <IncidentList
                incidents={filteredIncidents}
                selectedIncidentId={selectedIncident?.id ?? null}
                onSelectIncident={handleSelectIncident}
                isLoading={isLoading}
                userLocation={userLocation}
                lastUpdated={lastUpdated}
            />
            <HistoryList incidents={viewHistory} onSelectIncident={handleSelectIncident} />
        </div>

        <div className="col-span-1 lg:col-span-2 xl:col-span-3 p-6 overflow-y-auto">
          {selectedIncident ? (
            <IncidentDetail 
              incident={selectedIncident} 
              summary={summary} 
              isSummaryLoading={isSummaryLoading} 
            />
          ) : (
            <div className="flex justify-center items-center h-full">
              <div className="text-center text-slate-500">
                <h2 className="text-2xl font-semibold">Welcome to the Incident Monitor</h2>
                <p className="mt-2">Select an incident from the list to view details and get an AI-powered summary.</p>
              </div>
            </div>
          )}
        </div>
      </main>
      <DebugPane data={debugData} />
    </div>
  );
};

export default App;
