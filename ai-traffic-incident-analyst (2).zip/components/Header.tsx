import React from 'react';
import { RoadIcon, RefreshIcon, CrosshairIcon, ChatBubbleIcon } from './Icons';

interface HeaderProps {
  onRefresh: () => void;
  isLoading: boolean;
  onToggleLocation: () => void;
  isTracking: boolean;
  onFeedbackClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onRefresh, isLoading, onToggleLocation, isTracking, onFeedbackClick }) => {
  return (
    <header className="bg-brand-primary text-white shadow-md p-4 flex justify-between items-center z-20">
      <div className="flex items-center">
        <RoadIcon className="w-8 h-8 mr-3" />
        <h1 className="text-2xl font-bold tracking-tight">Real-Time Traffic Incident Monitor</h1>
      </div>
      <div className="flex items-center gap-4">
        <button
          onClick={onFeedbackClick}
          className="flex items-center justify-center p-2 rounded-full bg-white bg-opacity-10 hover:bg-opacity-20 transition-colors focus:outline-none focus:ring-2 focus:ring-white"
          aria-label="Provide feedback"
        >
          <ChatBubbleIcon className="w-6 h-6 text-white" />
        </button>
        <button
          onClick={onToggleLocation}
          className="flex items-center justify-center p-2 rounded-full bg-white bg-opacity-10 hover:bg-opacity-20 transition-colors focus:outline-none focus:ring-2 focus:ring-white"
          aria-label={isTracking ? "Disable location tracking" : "Enable location tracking"}
        >
          <CrosshairIcon className={`w-6 h-6 ${isTracking ? 'text-status-green animate-pulse-fast' : 'text-white'}`} />
        </button>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="flex items-center justify-center p-2 rounded-full bg-white bg-opacity-10 hover:bg-opacity-20 transition-colors focus:outline-none focus:ring-2 focus:ring-white disabled:opacity-50 disabled:cursor-not-allowed"
          aria-label="Refresh incidents"
        >
          <RefreshIcon className={`w-6 h-6 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>
    </header>
  );
};

export default Header;